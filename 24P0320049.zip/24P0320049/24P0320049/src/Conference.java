// Generices Class
public class Conference <t> {

    private t Date;
    private t Tutorials;
    private t Workshop;
    private t Paper_Presentations;
    private t Poster_Presentations;
    
    Conference(t Data, t Tutorials, t Workshop, t Paper_Presentations, t Poster_Presentations){
     this.Date = Data;
     this.Tutorials = Tutorials;
     this.Workshop = Workshop;
     this.Paper_Presentations = Paper_Presentations;
     this.Poster_Presentations = Poster_Presentations;
    }

    public Conference() {

    }

    public t getDate() {
        return Date;
    }

    public Conference setDate(t date) {
        Date = date;
        return null;
    }

    public t getTutorials() {
        return Tutorials;
    }

    public void setTutorials(t tutorials) {
        Tutorials = tutorials;
    }

    public t getWorkshop() {
        return Workshop;
    }

    public void setWorkshop(t workshop) {
        Workshop = workshop;
    }

    public t getPaper_Presentations() {
        return Paper_Presentations;
    }

    public void setPaper_Presentations(t paper_Presentations) {
        Paper_Presentations = paper_Presentations;
    }

    public t getPoster_Presentations() {
        return Poster_Presentations;
    }

    public void setPoster_Presentations(t poster_Presentations) {
        Poster_Presentations = poster_Presentations;
    }
}

