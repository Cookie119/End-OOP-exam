import java.awt.image.ImageConsumer;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Generices Array list
        Conference<Integer> Dates_of_Conferences = new Conference<Integer>();
        Conference<String> Tutorials_of_Conferences  = new Conference<String>();
        Conference<String> Workshop_of_Conferences  = new Conference<String>();
        Conference<String> Paper_Presentations_of_Conferences  = new Conference<String>();
        Conference<String> Poster_Presentations_of_Conferences  = new Conference<String>();
        // Generices Array list for ICON and FIRE
            ArrayList<Conference> ICON = new ArrayList<Conference>();
            ArrayList<Conference> FIRE = new ArrayList<Conference>();
        int count_poster = 0;
        while (true){
            Scanner input = new Scanner(System.in);
            // list of option using while loop
        System.out.println("Choose A option from the list:");

            System.out.println("1---Add-Date");
            System.out.println("2---Add-Tutorial");
            System.out.println("3---Add-Workshop");
            System.out.println("4---Add-Paper");
            System.out.println("5---Add-Poster");
            System.out.println("6---Display Details");
            System.out.println("7---Exit");
            int choose = input.nextInt();
            input.nextLine();

        switch (choose) {
            case 1:{
                try {
                    System.out.println("Choose the Conference ");
                    System.out.println("1--- Conference ICON ");
                    System.out.println("2--- Conference FIRE ");
                    int Conf = input.nextInt();
                    input.nextLine();
                    if (Conf == 1) {

                        System.out.println("Enter A Date For the Events:");
                        int Date = input.nextInt();
                        ICON.add(Dates_of_Conferences.setDate(Date));
                        System.out.println("Date Entered SuccessFully");
                    }
                    else {
                        System.out.println("Enter A Date For the Events:");
                        int Date = input.nextInt();
                         FIRE.add(Dates_of_Conferences.setDate(Date));
                        System.out.println("Date Entered SuccessFully");
                    }
                }

                catch (Exception e){
                    System.out.println("Wanted A date to be Entered In Number "+e);
                }

                break;

            }
            case 2:{

                try {
                    System.out.println("Choose the Conference ");
                    System.out.println("1--- Conference ICON ");
                    System.out.println("2--- Conference FIRE ");
                    int Conf = input.nextInt();
                    input.nextLine();
                    String Tutorials_Name = input.nextLine();
                    if (Conf == 1) {
                        System.out.println("Enter A Tutorial For the Conference:");
                        Tutorials_of_Conferences.setTutorials(Tutorials_Name);
                        System.out.println(" Entered Tutorials SuccessFully");
                    }
                    else{
                        System.out.println("Enter A Tutorial For the Conference:");
                        Tutorials_of_Conferences.setTutorials(Tutorials_Name);
                        System.out.println(" Entered Tutorials SuccessFully");
                    }
                }
                catch (Exception e){
                    System.out.println("Wanted A date to be String In Number "+e);
                }
                break;
            }
            case 3:{
                System.out.println(" \n Enter A Workshop For the Conference:");
                String setWorkshop_Name = input.nextLine();
                Workshop_of_Conferences.setWorkshop(setWorkshop_Name);
                break;
            }
            case 4:{
                System.out.println(" \n Enter A Paper_Presentations_Name For the Conference:");
                String Paper_Presentations_Name = input.nextLine();
                Paper_Presentations_of_Conferences.setPaper_Presentations(Paper_Presentations_Name);
                break;
            }
            case 5:{
                    System.out.println(" \nEnter A Poster_Presentations_Name For the Conference:");
                    String Poster_Presentations_Name = input.nextLine();
                    Poster_Presentations_of_Conferences.setPoster_Presentations(Poster_Presentations_Name);
                break;
            }
            case 6: {
                System.out.println(" \nEnter A Date to Display the Events:");
                Dates_of_Conferences.getDate();
                Tutorials_of_Conferences.getTutorials();
                Workshop_of_Conferences.getWorkshop();
                Paper_Presentations_of_Conferences.getPaper_Presentations();
                Poster_Presentations_of_Conferences.getPoster_Presentations();
                break;
            }

            case 7 :{
                System.out.println(" \n Exit...");
                System.exit(0);

            }
            default:{
                System.out.println("Choose from above only");
            }
        }
          }



    }
}